<?php


class VueProfil extends VueGenerique
{

    public function __construct()
    {
        parent::__construct();
    }

    public function afficher_profil($profileData)
    {
 
?>
<style>
    .profil-container {
    background: url('chemin_vers_image_de_fond.jpg') no-repeat center center;
    background-size: cover;
    padding: 20px;
    color: #fff; /* ou toute autre couleur de texte */
}

.profil-header {
    text-align: center;
}

.profil-picture {
    /* Ajoutez des styles pour la photo de profil si nécessaire */
}

.profil-form {
    /* Ajoutez des styles pour votre formulaire */
    background: rgba(0, 0, 0, 0.5); /* fond semi-transparent pour les zones de texte */
    padding: 20px;
    border-radius: 10px;
}

.profil-form .form-group {
    margin-bottom: 20px;
}

.profil-form .form-group label {
    display: block;
}

.profil-form .form-group input,
.profil-form .form-group textarea {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: none;
    background-color: #fff;
    border-radius: 5px;
}

.profil-actions {
    text-align: right;
}

.profil-actions button {
    padding: 10px 20px;
    margin-left: 10px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

/* Ajoutez des styles supplémentaires pour les boutons et les entrées */

</style>

<div class="profil-container">
    <div class="profil-header">
        <div class="profil-picture">
            <!-- La photo de profil peut être ajoutée ici -->
        </div>
        <h1><?php echo htmlspecialchars($profileData['login']); ?></h1>
    </div>
    <form class="profil-form" id="profilForm">
        <div class="form-group">
            <label for="biographie">Biographie :</label>
            <textarea id="biographie" name="biographie"><?php echo htmlspecialchars($profileData['biographie']); ?></textarea>
        </div>
        <div class="form-group">
            <label for="pays">Pays :</label>
            <input type="text" id="pays" name="pays" value="<?php echo htmlspecialchars($profileData['pays']); ?>">
        </div>
        <div class="form-group">
            <label for="login">Login* :</label>
            <input type="text" id="login" name="login" value="<?php echo htmlspecialchars($profileData['login']); ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Mail* :</label>
            <input type="email" id="email" name="mail" value="<?php echo htmlspecialchars($profileData['mail']); ?>">
        </div>
        <div class="profil-actions">
            <button type="reset">Abandonner les modifications</button>
            <button type="submit">Sauvegarder</button>
        </div>

       
    </form>
</div>


<?php
    }
}
?>