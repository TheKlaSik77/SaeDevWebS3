package fr.iut.montreuil.metallic_infestation.modele.effets;

import fr.iut.montreuil.metallic_infestation.modele.ennemis.Ennemi;

public interface Effet {

    public void appliquerEffet(Ennemi ennemi);
}
