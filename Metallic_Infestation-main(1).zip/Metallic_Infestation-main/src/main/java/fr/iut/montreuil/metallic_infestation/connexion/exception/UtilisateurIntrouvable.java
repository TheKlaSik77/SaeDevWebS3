package fr.iut.montreuil.metallic_infestation.connexion.exception;

public class UtilisateurIntrouvable extends Exception{
}
