package fr.iut.montreuil.metallic_infestation.connexion.exception;

public class UtilisateurDejaConnecté extends Exception{
}
