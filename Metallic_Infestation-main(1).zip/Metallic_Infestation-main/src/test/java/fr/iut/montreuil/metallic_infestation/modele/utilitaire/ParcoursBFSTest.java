package fr.iut.montreuil.metallic_infestation.modele.utilitaire;

import static org.junit.jupiter.api.Assertions.*;

class ParcoursBFSTest {
    /**
     * Classe était intéressante à tester d'un point de vue algorithmique.
     * Cependant, dans notre menu principal, nous chargeons 3 maps différentes et nous pouvons observer que le BFS fonctionne toujours correctement.
     * C'est pourquoi les jeux de tests ont été dirigés vers d'autres classes.
     */
}