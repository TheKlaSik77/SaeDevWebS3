package fr.iut.montreuil.metallic_infestation.modele.utilitaire;

public class LiaisonEntreLeMenuEtLeJeu {

    public static int nbTerrain = 0;

}
