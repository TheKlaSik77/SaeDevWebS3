<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.0" name="bunkers_1x1" tilewidth="32" tileheight="32" tilecount="4" columns="2">
 <image source="../../../../../../../../../../../../../Images/bunkers/bunkers_1x1.png" width="90" height="80"/>
</tileset>
